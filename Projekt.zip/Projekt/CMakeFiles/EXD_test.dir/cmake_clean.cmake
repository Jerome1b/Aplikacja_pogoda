file(REMOVE_RECURSE
  "CMakeFiles/EXD_test.dir/link.d"
  "CMakeFiles/EXD_test.dir/src/Extract_Data_Mock.cpp.o"
  "CMakeFiles/EXD_test.dir/src/Extract_Data_Mock.cpp.o.d"
  "CMakeFiles/EXD_test.dir/src/ZapisDane.cpp.o"
  "CMakeFiles/EXD_test.dir/src/ZapisDane.cpp.o.d"
  "CMakeFiles/EXD_test.dir/tests/test_mock.cpp.o"
  "CMakeFiles/EXD_test.dir/tests/test_mock.cpp.o.d"
  "EXD_test"
  "EXD_test.pdb"
  "EXD_test[1]_tests.cmake"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/EXD_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
