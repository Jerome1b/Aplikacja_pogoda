file(REMOVE_RECURSE
  "CMakeFiles/main.dir/link.d"
  "CMakeFiles/main.dir/src/Extract_Data_Mock.cpp.o"
  "CMakeFiles/main.dir/src/Extract_Data_Mock.cpp.o.d"
  "CMakeFiles/main.dir/src/Localization.cpp.o"
  "CMakeFiles/main.dir/src/Localization.cpp.o.d"
  "CMakeFiles/main.dir/src/Wind_inf.cpp.o"
  "CMakeFiles/main.dir/src/Wind_inf.cpp.o.d"
  "CMakeFiles/main.dir/src/ZapisDane.cpp.o"
  "CMakeFiles/main.dir/src/ZapisDane.cpp.o.d"
  "CMakeFiles/main.dir/src/main.cpp.o"
  "CMakeFiles/main.dir/src/main.cpp.o.d"
  "main"
  "main.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/main.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
