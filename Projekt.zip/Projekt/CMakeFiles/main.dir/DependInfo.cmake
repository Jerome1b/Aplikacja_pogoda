
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/jedrzej/Pulpit/Projekt/src/Extract_Data_Mock.cpp" "CMakeFiles/main.dir/src/Extract_Data_Mock.cpp.o" "gcc" "CMakeFiles/main.dir/src/Extract_Data_Mock.cpp.o.d"
  "/home/jedrzej/Pulpit/Projekt/src/Localization.cpp" "CMakeFiles/main.dir/src/Localization.cpp.o" "gcc" "CMakeFiles/main.dir/src/Localization.cpp.o.d"
  "/home/jedrzej/Pulpit/Projekt/src/Wind_inf.cpp" "CMakeFiles/main.dir/src/Wind_inf.cpp.o" "gcc" "CMakeFiles/main.dir/src/Wind_inf.cpp.o.d"
  "/home/jedrzej/Pulpit/Projekt/src/ZapisDane.cpp" "CMakeFiles/main.dir/src/ZapisDane.cpp.o" "gcc" "CMakeFiles/main.dir/src/ZapisDane.cpp.o.d"
  "/home/jedrzej/Pulpit/Projekt/src/main.cpp" "CMakeFiles/main.dir/src/main.cpp.o" "gcc" "CMakeFiles/main.dir/src/main.cpp.o.d"
  "" "main" "gcc" "CMakeFiles/main.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
