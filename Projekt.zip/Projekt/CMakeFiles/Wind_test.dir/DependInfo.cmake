
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/jedrzej/Pulpit/Projekt/src/Wind_inf.cpp" "CMakeFiles/Wind_test.dir/src/Wind_inf.cpp.o" "gcc" "CMakeFiles/Wind_test.dir/src/Wind_inf.cpp.o.d"
  "/home/jedrzej/Pulpit/Projekt/tests/Wind_test.cpp" "CMakeFiles/Wind_test.dir/tests/Wind_test.cpp.o" "gcc" "CMakeFiles/Wind_test.dir/tests/Wind_test.cpp.o.d"
  "" "Wind_test" "gcc" "CMakeFiles/Wind_test.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
