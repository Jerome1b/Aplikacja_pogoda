file(REMOVE_RECURSE
  "CMakeFiles/Wind_test.dir/link.d"
  "CMakeFiles/Wind_test.dir/src/Wind_inf.cpp.o"
  "CMakeFiles/Wind_test.dir/src/Wind_inf.cpp.o.d"
  "CMakeFiles/Wind_test.dir/tests/Wind_test.cpp.o"
  "CMakeFiles/Wind_test.dir/tests/Wind_test.cpp.o.d"
  "Wind_test"
  "Wind_test.pdb"
  "Wind_test[1]_tests.cmake"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Wind_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
