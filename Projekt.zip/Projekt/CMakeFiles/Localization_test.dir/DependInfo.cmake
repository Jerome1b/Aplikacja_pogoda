
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/jedrzej/Pulpit/Projekt/src/Localization.cpp" "CMakeFiles/Localization_test.dir/src/Localization.cpp.o" "gcc" "CMakeFiles/Localization_test.dir/src/Localization.cpp.o.d"
  "/home/jedrzej/Pulpit/Projekt/tests/Test_Localization.cpp" "CMakeFiles/Localization_test.dir/tests/Test_Localization.cpp.o" "gcc" "CMakeFiles/Localization_test.dir/tests/Test_Localization.cpp.o.d"
  "" "Localization_test" "gcc" "CMakeFiles/Localization_test.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
