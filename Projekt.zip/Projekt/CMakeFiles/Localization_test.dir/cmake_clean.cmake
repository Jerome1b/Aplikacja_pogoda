file(REMOVE_RECURSE
  "CMakeFiles/Localization_test.dir/link.d"
  "CMakeFiles/Localization_test.dir/src/Localization.cpp.o"
  "CMakeFiles/Localization_test.dir/src/Localization.cpp.o.d"
  "CMakeFiles/Localization_test.dir/tests/Test_Localization.cpp.o"
  "CMakeFiles/Localization_test.dir/tests/Test_Localization.cpp.o.d"
  "Localization_test"
  "Localization_test.pdb"
  "Localization_test[1]_tests.cmake"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Localization_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
