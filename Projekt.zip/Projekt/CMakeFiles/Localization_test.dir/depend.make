# Empty dependencies file for Localization_test.
# This may be replaced when dependencies are built.
